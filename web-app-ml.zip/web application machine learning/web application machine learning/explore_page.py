import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd
def shorten_categories(categories,cutoff):
    categorical_map={}

    for i in range(len(categories)):

        if categories.values[i] >= cutoff:
        
            categorical_map[categories.index[i]] = categories.index[i]
           
        else:
             categorical_map[categories.index[i]] = 'other'
    return categorical_map

def clean_experience(x):
    if x == 'More than 50 years':
        return 50
    if x == 'Less than 1 year':
        return 0.5
    return float(x)

def clean_education(x):
    if "Bachelor's degree" in x:
        return "Bachelor's degree"
    if "Master's degree" in x:
        return "Master's degree"
    if "Professional degree" in x or "Other doctoral" in x:
        return "post grad"
     
    return "less than a Bachelor's"

@st.cache_data
def load_data():
    data = pd.read_csv("survey_results_public.csv")
    
    data = data[['Country','EdLevel','YearsCodePro','Employment','ConvertedComp']]
    
    
    # data =data[data['ConvertedCompConvertedComp'].notnull()]
    
    data = data.dropna()
    
    data = data[data['Employment']=="Employed full-time"]
    data = data.drop("Employment",axis=1)
    
    country_map = shorten_categories(data['Country'].value_counts(),400)
    data['Country'] = data['Country'].map(country_map)
    data =data[data['ConvertedComp'] <= 250000]
    data = data[data['ConvertedComp'] >= 10000]
    data = data[data['Country'] != 'other']
    
    data['YearsCodePro'] = data['YearsCodePro'].apply(clean_experience)
    
    data['EdLevel'] = data['EdLevel'].apply(clean_education)
    data = data.rename({'ConvertedComp':'salary'},axis=1) 
    return data

data = load_data()


def show_explore_page():
    
    st.title("Explore software engineering salaries")

    st.write("""### 
               stack overflow developer survey 2020
             """)
    data = load_data()
    data = data['Country'].value_counts()
    
    fig1,ax1 = plt.subplots()
    ax1.pie(data,labels=data.index,autopct="%1.1f%%",shadow=True,startangle=90)
    
    ax1.axis("equal")
     
    st.write("""
              ### number of data from different countries
             """)
    
    st.pyplot(fig1)
    
    st.write("""
              ### mean salary based on country
             """)
    data = load_data()
    data = data.groupby(['Country'])['salary'].mean().sort_values(ascending=True)
    st.bar_chart(data)
    
    st.write("""
             ### mean salary based on experience
             """)
    data = load_data()
    data = data.groupby(['YearsCodePro'])['salary'].mean().sort_values(ascending=True)
    st.line_chart(data)